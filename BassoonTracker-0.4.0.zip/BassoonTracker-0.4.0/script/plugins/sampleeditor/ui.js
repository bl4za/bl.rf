SampleEditor.SUI = function(){
    var me = {};

    console.log("SUI!");

    me.init = function(){
        console.log("SUI init");
    };

    return me;
}();