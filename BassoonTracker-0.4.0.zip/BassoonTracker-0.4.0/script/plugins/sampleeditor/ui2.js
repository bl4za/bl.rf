SampleEditor.SUI2 = function(){
    var me = {};

    console.log("SUI 2!");

    me.init = function(){
        console.log("SUI 2 init");
    };

    return me;
}();