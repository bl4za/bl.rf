var Config = (function(){

    var me = {};

    me.modArchiveApiKey = "Enter you modArchive API key here";
    // see https://modarchive.org/?xml-api for more info

    return me;
}());

module.exports = Config;